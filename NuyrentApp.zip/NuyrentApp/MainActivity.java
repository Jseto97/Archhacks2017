package com.example.merlin.nutryent3;

import android.app.ActionBar;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.support.annotation.NonNull;
import android.widget.Toast;



import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;

import java.util.UUID;


public class MainActivity extends Activity {

    ImageView cameraImageView;


    TextView txtView;
    TextView txtView2;
    TextView strtPrompt;
    TextView afterCapture;

    private Uri filePath; //internal file path of photo

    int yo = 0;

    static final int CAM_REQUEST = 1;
    public Button continueButton;
    public Button button1;
    public Button button2;

    //Firebase
    FirebaseStorage storage;
    StorageReference storageReference;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //FIREBASE INIT
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();



        cameraImageView = (ImageView) findViewById(R.id.setPhoto);
        button1 = (Button) findViewById(R.id.cameraButton);
        button2 = (Button) findViewById(R.id.upload);
        continueButton = (Button) findViewById(R.id.continueButton);


        button1.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View v) {
                afterCapture = (TextView) findViewById(R.id.happy);
                strtPrompt = (TextView) findViewById(R.id.startPrompt);
                txtView = (TextView) findViewById(R.id.textView);
                txtView2 = (TextView) findViewById(R.id.textView2);
                txtView2.setVisibility(View.INVISIBLE);
                txtView.setVisibility(View.INVISIBLE);
                strtPrompt.setVisibility(View.INVISIBLE);
                continueButton.setVisibility(View.VISIBLE);
                afterCapture.setVisibility(View.VISIBLE);



                Intent camera_intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

                startActivityForResult(camera_intent, CAM_REQUEST);
                yo = 0;



            }


        });
        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View V){
                afterCapture = (TextView) findViewById(R.id.happy);
                strtPrompt = (TextView) findViewById(R.id.startPrompt);
                txtView = (TextView) findViewById(R.id.textView);
                txtView2 = (TextView) findViewById(R.id.textView2);
                txtView2.setVisibility(View.INVISIBLE);
                txtView.setVisibility(View.INVISIBLE);
                strtPrompt.setVisibility(View.INVISIBLE);
                continueButton.setVisibility(View.VISIBLE);
                afterCapture.setVisibility(View.VISIBLE);
                yo  = 1;
                chooseImage();


            }
        });

        continueButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                uploadImage();
                Intent nextPage = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(nextPage);

            }
        });
    }

    private void uploadImage(){

        if(filePath!=null){
            final ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();


            StorageReference ref = storageReference.child("images/"+ UUID.randomUUID().toString());
            ref.putFile(filePath)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Uploaded",Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            progressDialog.dismiss();
                            Toast.makeText(MainActivity.this, "Failed" +e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0*taskSnapshot.getBytesTransferred()/taskSnapshot.getTotalByteCount());
                            progressDialog.setMessage("Uploaded "+ (int)progress+"%");
                        }
                    });


        }
    }

    private void chooseImage(){
        Intent intent2 = new Intent();
        intent2.setType("image/*");
        intent2.setAction(intent2.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent2, "Select Picture"), CAM_REQUEST);




    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);


        if (requestCode == CAM_REQUEST && resultCode == RESULT_OK && yo == 0){


            Bundle extras = data.getExtras();
            Bitmap photo = (Bitmap)extras.get("data");


            cameraImageView.setImageBitmap(photo);


        }
        else if (requestCode == CAM_REQUEST && resultCode == RESULT_OK && data!=null && data.getData() != null && yo == 1 ){

            filePath = data.getData();
            try {
                Bitmap photo = MediaStore.Images.Media.getBitmap(getContentResolver(), filePath);
                cameraImageView.setImageBitmap(photo);
            }
            catch(IOException e){
                e.printStackTrace();

            }


        }
    }
}
